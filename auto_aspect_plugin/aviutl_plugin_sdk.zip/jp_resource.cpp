#include <windows.h>

BOOL WINAPI DllMain( HINSTANCE hInstance,DWORD dwNotification,LPVOID lpReserved )
{
	return TRUE;
}



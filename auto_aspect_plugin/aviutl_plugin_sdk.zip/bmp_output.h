#define	IDC_EDIT0	100


